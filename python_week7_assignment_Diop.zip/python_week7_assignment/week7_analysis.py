# Python Week 7 Assignment
# Objective: Load and analyze Iris dataset using pandas and matplotlib

import pandas as pd
import matplotlib.pyplot as plt

# Task 1: Load and Explore the Dataset
try:
    df = pd.read_csv('iris.csv')  # Load CSV
    print("First 5 rows of the dataset:\n", df.head())
    print("\nData Types and Info:")
    print(df.info())
    print("\nMissing Values:\n", df.isnull().sum())
    df.dropna(inplace=True)  # Clean: drop missing values if any
except FileNotFoundError:
    print("Error: iris.csv not found!")

# Task 2: Basic Data Analysis
print("\nSummary Statistics:\n", df.describe())
print("\nGroup by species (Mean):\n", df.groupby('species').mean())

# Task 3: Data Visualization

# Line Chart - Sepal Length & Petal Length
plt.figure(figsize=(10,5))
plt.plot(df['sepal_length'], label='Sepal Length')
plt.plot(df['petal_length'], label='Petal Length')
plt.title('Sepal & Petal Length Trend')
plt.xlabel('Index')
plt.ylabel('Length (cm)')
plt.legend()
plt.grid(True)
plt.show()

# Bar Chart - Average petal length per species
plt.figure(figsize=(8,5))
df.groupby('species')['petal_length'].mean().plot(kind='bar', color='skyblue')
plt.title('Average Petal Length by Species')
plt.xlabel('Species')
plt.ylabel('Petal Length')
plt.grid(axis='y')
plt.show()

# Histogram - Sepal Width
plt.figure(figsize=(8,5))
df['sepal_width'].plot(kind='hist', bins=10, color='orange', edgecolor='black')
plt.title('Distribution of Sepal Width')
plt.xlabel('Sepal Width (cm)')
plt.grid(True)
plt.show()

# Scatter Plot - Sepal Length vs Petal Length
plt.figure(figsize=(8,5))
plt.scatter(df['sepal_length'], df['petal_length'], c='green', alpha=0.6)
plt.title('Sepal Length vs Petal Length')
plt.xlabel('Sepal Length (cm)')
plt.ylabel('Petal Length (cm)')
plt.grid(True)
plt.show()
